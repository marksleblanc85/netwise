<?php extend_template('default') ?>

<?=$output?>